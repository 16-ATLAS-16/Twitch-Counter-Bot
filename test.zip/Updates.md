Hello again!
I hope v2.1.1 is serving you all well, and I hope it is less annoying now.
First of all, v2.1.2 is around the corner with major speed improvements ;)
Second things second, here's the new to do list:

Additions: 
1) Add the ability to ban a given set of users (txt file?)
2) Still change the damn colours, black and white kinda gives an old console or CLI feel that isn't as friendly as I'd like.
3) Add action highlights
4) Add the counter to show how close the bot is to having a bot raid event triggered.

Extras:
1) LINUX SUPPORT GODDAMMIT
2) Support for running on multiple streams? (I'm looking at you, chat mods. I wanna make this easier for yall)
3) uhhhhhhhhhh
4) Support discord? We'll see about how many braincells I have left after next release

Aight that's all for 2.1.1, see yall in the release notes of v2.1.2

Note: TWITCH FIX YOUR PLATFORM (or hire me whichever)
