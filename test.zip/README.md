# Twitch-Counter-Bot
A twitch bot that counters all follow-bots and chatbots. Also a utility bot for mobile chat mods. (seriously twitch, fix your app).

Created using the Twitchio Bot/API wrapper for Twitch.

[Twitch Counter-Bot](https://www.github.com/16-ATLAS-16/Twitch-Counter-Bot) © 2021 by [ATLAS](https://www.twitter.com/TheATLAS16) is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/)



NOTE: this is a work in progress, features, quality of life improvements, and even support for other platforms such as Linux will be added along the way.
